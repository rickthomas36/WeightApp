// Item.java
package com.example.richardsweighttrackingapp;

public class Item {
    private String name;
    private int value;

    // Constructor, getters, and setters
    public Item(String name, int value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public int getValue() {
        return value;
    }
}
