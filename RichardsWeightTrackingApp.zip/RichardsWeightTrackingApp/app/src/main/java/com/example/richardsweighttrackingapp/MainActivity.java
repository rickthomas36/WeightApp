package com.example.richardsweighttrackingapp;

import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ItemAdapter itemAdapter;
    private List<ClipData.Item> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the Login button and set up the onClick listener
        Button btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
        });

        // Find the SMS Notification button and set up the onClick listener
        Button btnSmsNotification = findViewById(R.id.btnSmsNotification);
        btnSmsNotification.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SMSNotificationActivity.class);
            startActivity(intent);
        });
    }
}

