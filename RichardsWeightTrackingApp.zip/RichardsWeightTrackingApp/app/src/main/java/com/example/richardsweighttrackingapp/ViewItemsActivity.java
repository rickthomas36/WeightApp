package com.example.richardsweighttrackingapp;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import androidx.appcompat.app.AppCompatActivity;

public class ViewItemsActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_items);  // Your layout containing the ListView

        dbHelper = new DatabaseHelper(this);  // Initialize the database helper

        // Get the ListView from the layout
        ListView listView = findViewById(R.id.listView);

        // Fetch all users (or items if you have a different table)
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + DatabaseHelper.TABLE_USERS, null);

        // Define which columns to display in the ListView
        String[] fromColumns = {DatabaseHelper.COLUMN_USERNAME, DatabaseHelper.COLUMN_PASSWORD};  // Display both columns
        int[] toViews = {R.id.item_name, R.id.item_value};  // Link to custom TextViews in list_item_layout.xml

        // Create a SimpleCursorAdapter to map the columns to the views
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                this,
                R.layout.list_item_layout,  // Use custom layout for each item
                cursor,  // Cursor with user data
                fromColumns,  // Columns to display
                toViews,  // Views where the columns should go
                0  // No flags needed
        );

        // Set the adapter to the ListView
        listView.setAdapter(adapter);

        // Optionally set up an onItemClickListener if you want to handle item clicks
        listView.setOnItemClickListener((parent, view, position, id) -> {
            // Handle item clicks here, if necessary
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dbHelper.close();  // Don't forget to close the database when done
    }
}


