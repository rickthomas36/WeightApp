package com.example.weighttracker;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class WeightGridActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_grid); // Ensure this layout exists
    }
}